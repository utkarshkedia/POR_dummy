from django.contrib import admin
from .models import GPU

admin.site.register(GPU)

# Register your models here.
