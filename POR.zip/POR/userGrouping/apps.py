from django.apps import AppConfig


class UsergroupingConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'userGrouping'
